import java.util.LinkedList;
import java.util.Scanner;

class Patient {
    int pID;          
    String pName;     
    String Mcond;     
    int priority;     
    Patient next;     
    Patient prev;     
    
    public Patient(int pID, String pName, String Mcond, int priority) {
        this.pID = pID;
        this.pName = pName;
        this.Mcond = Mcond;
        this.priority = priority;
        this.next = null;
        this.prev = null;
    }

    @Override
    public String toString() {
        return "Patient ID: " + pID + ", Patient Name: " + pName + ", Patient Medical Condition: " + Mcond + ", Priority: " + priority;
    }
}
class ClinictManagementSystem {
    private Patient head;          
    private Patient tail;          
    private LinkedList<Patient> patientHistory; 

    public ClinictManagementSystem() {
        head = null;
        tail = null;
        patientHistory = new LinkedList<>();
    }
    
    public void add(int pID, String pName, String rForV, int priority) {
        Patient newPatient = new Patient(pID, pName, rForV, priority);
        if (head == null) {
            head = tail = newPatient; 
        } else {
            tail.next = newPatient;    
            newPatient.prev = tail;     
            tail = newPatient;          
        }
        System.out.println("Patient added: " + pName);
    }
    
     public void viewwaitinglist() {
        if (head == null) {
            System.out.println("No patients in the waiting list.");
            return;
        }
        System.out.println("Current Waiting List:");
        Patient current = head;
        while (current != null) {
            System.out.println(current);
            current = current.next; 
        }
    }

    public void viewpatienthistory() {
        if (patientHistory.isEmpty()) {
            System.out.println("No patients have been attended yet.");
            return;
        }
        System.out.println("Patient History:");
        for (Patient p : patientHistory) {
            System.out.println(p);
        }
    }
    public void prioritize(int patientId) {
        Patient current = head;
        while (current != null && current.pID != patientId) {
            current = current.next;
        }
        if (current == null) {
            System.out.println("Patient not found.");
            return;
        }
        if (current == head) {
            System.out.println("Patient is already at the front of the list.");
            return;
        }
        if (current.prev != null) current.prev.next = current.next;
        if (current.next != null) current.next.prev = current.prev;
        if (current == tail) tail = current.prev; // Update tail if needed

        current.next = head;
        head.prev = current;
        current.prev = null;
        head = current;
        System.out.println("Patient prioritized: " + current.pName);
    }

    public void attend() {
        if (head == null) {
            System.out.println("No patients waiting.");
            return;
        }
        Patient attended = head; 
        patientHistory.add(attended); 
        head = head.next; 
        if (head != null) {
            head.prev = null; 
        } else {
            tail = null; 
        }
        System.out.println("Attended patient: " + attended.pName);
    }
public void adjustpriorities() {
    if (head == null) return; 
    Patient current = head;
    Patient previous = null;

    while (current != null) {
        current.priority--; 
        if (current.priority <= 0) {
            if (current == head) {
                head = current.next;
                current = head;
            } else {
                previous.next = current.next;
                current = previous.next;
            }
        } else {
            previous = current;
            current = current.next;
        }
    }

    System.out.println("Adjusted patient priorities based on waiting time.");
}
public void deleteAppointment(int pID) {
    Patient current = head;

    while (current != null) {
        if (current.pID == pID) {
            if (current.prev != null) {
                current.prev.next = current.next; 
            } else {
                head = current.next; 
            }

            if (current.next != null) {
                current.next.prev = current.prev; 
            } else {
                tail = current.prev; 
            }
            patientHistory.add(current);

            System.out.println("Cancelled appointment for: " + current);
            return;
        }
        current = current.next; 
    }

    System.out.println("Patient with ID " + pID + " not found.");
}
}
public class finalProject {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ClinictManagementSystem system = new ClinictManagementSystem();
        while (true) {
            System.out.println("\n=== Clinic Management System ===");
            System.out.println("1. Add Patient");
            System.out.println("2. Prioritize Patient");
            System.out.println("3. Attend Patient");
            System.out.println("4. View Waiting List");
            System.out.println("5. View Patient History");
            System.out.println("6. Adjust Priorities");
            System.out.println("7. Cancel Appointment");
            System.out.println("8. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1:
                    System.out.print("Enter Patient ID: ");
                    int id = scanner.nextInt();
                    scanner.nextLine(); 
                    System.out.print("Enter Patient Name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter Patient Medical Condition: ");
                    String reason = scanner.nextLine();
                    System.out.print("Enter Priority (higher number = lower priority): ");
                    int priority = scanner.nextInt();
                    system.add(id, name, reason, priority);
                    break;
                case 2:
                    System.out.print("Enter Patient ID to prioritize: ");
                    int prioritizeId = scanner.nextInt();
                    system.prioritize(prioritizeId);
                    break;
                case 3:
                    system.attend();
                    break;
                case 4:
                    system.viewwaitinglist();
                    break;
                case 5:
                    system.viewpatienthistory();
                    break;
                case 6:
                    system.adjustpriorities();
                    break;
                case 7:
                    System.out.print("Enter Patient ID to Cancel Appointment: ");
                    int deleteId = scanner.nextInt();
                    system.deleteAppointment(deleteId);
                    break;
                case 8:
                    System.out.println("Thank you for using our Clinic Management System");
                    System.out.println("Have A Great Day");
                    scanner.close();
                    return; 
                default:
                    System.out.println("Invalid choice Please try again.");
            }
        }
    }
}

