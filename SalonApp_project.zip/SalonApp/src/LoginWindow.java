import javax.swing.*;
import java.awt.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import static javax.swing.JFrame.EXIT_ON_CLOSE;

public class LoginWindow extends JFrame {
    public LoginWindow() {
        setTitle("salon - Login");
        setSize(400, 300);
        setLocationRelativeTo(null); 
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        Color bgColor = new Color(255, 228, 225);
        

        JPanel mainPanel = new JPanel();
        mainPanel.setBackground(bgColor);
        mainPanel.setLayout(new GridLayout(2, 1, 10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JLabel titleLabel = new JLabel("Login to salon website", JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        add(titleLabel, BorderLayout.NORTH);

        JTextField emailField = new JTextField();
        emailField.setBorder(BorderFactory.createTitledBorder("Email"));

        JPasswordField passwordField = new JPasswordField();
        passwordField.setBorder(BorderFactory.createTitledBorder("Password"));

        mainPanel.add(emailField);
        mainPanel.add(passwordField);

        add(mainPanel, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new GridLayout(1, 2, 10, 10));
        buttonPanel.setBackground(bgColor);
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JButton loginButton = new JButton("Login");
        JButton registerButton = new JButton("Register");
        customizeButton(loginButton, 35);
        customizeButton(registerButton, 35);

        buttonPanel.add(loginButton);
        buttonPanel.add(registerButton);

        add(buttonPanel, BorderLayout.SOUTH);

        loginButton.addActionListener(e -> {
            String email = emailField.getText();
            String password = new String(passwordField.getPassword());

            if (isLoginValid(email, password)) {
                JOptionPane.showMessageDialog(this, "Login successful!");
                new MenuWindow();
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Invalid email or password.");
            }
        });

        registerButton.addActionListener(e -> {
            new SignupWindow();
            dispose();
        });

        setVisible(true);
    }

    private boolean isLoginValid(String email, String password) {
        try (BufferedReader reader = new BufferedReader(new FileReader("users.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] userData = line.split(",");
                if (userData[0].equals(email) && userData[1].equals(password)) {
                    return true;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }

    private void customizeButton(JButton button,  int fontSize) {
        button.setForeground(Color.WHITE); 
        button.setBackground(Color.PINK); 
        button.setFont(new Font("Arial", Font.BOLD, fontSize));
    }
    

}

   
