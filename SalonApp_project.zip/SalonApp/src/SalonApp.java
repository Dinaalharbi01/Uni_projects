public class SalonApp {
    public static void main(String[] args) {
        new LoginWindow();
    }
}
