import javax.swing.*;
import java.awt.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MenuWindow extends JFrame {
    public MenuWindow() {
        setTitle("Salon - Menu");
        setSize(500, 350);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(255, 228, 225)); 

        
        ImageIcon originalIcon = new ImageIcon("pink.jpg");
        Image img = originalIcon.getImage().getScaledInstance(500, 200, Image.SCALE_SMOOTH); 
        JLabel imageLabel = new JLabel(new ImageIcon(img));
        panel.add(imageLabel, BorderLayout.NORTH);

        JLabel welcomeLabel = new JLabel("Experience the Best Beauty Services", JLabel.CENTER);
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 20));
        welcomeLabel.setForeground(Color.BLACK); 
        panel.add(welcomeLabel, BorderLayout.CENTER);

        JMenuBar menuBar = new JMenuBar();
        JMenu menu = new JMenu("Menu");
        JMenuItem bookAppointmentItem = new JMenuItem("Book Appointment");
        
        bookAppointmentItem.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
        new BookingWindow(); 
        dispose(); 
    }
});
        menu.add(bookAppointmentItem);
        menuBar.add(menu);
        setJMenuBar(menuBar);

        
        add(panel);
        setVisible(true);
    }

    
}