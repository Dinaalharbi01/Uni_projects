import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileWriter;
import java.io.IOException;

public class BookingWindow extends JFrame {
    public BookingWindow() {
        setTitle("Salon - Booking");
        setSize(450, 350);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        Color bgColor = new Color(255, 228, 225); 
         
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new GridLayout(0, 1, 10, 10)); 
        mainPanel.setBackground(bgColor);
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        
        JCheckBox hairCut = new JCheckBox("Hair Cut - 150SR");
        hairCut.setBackground(bgColor);
        JCheckBox facial = new JCheckBox("Facial - 250SR");
        facial.setBackground(bgColor);
        JCheckBox massage = new JCheckBox("Massage - 340SR");
        massage.setBackground(bgColor);
        JCheckBox nails = new JCheckBox("Nails - 120SR");
        nails.setBackground(bgColor);

        JComboBox<String> timeBox = new JComboBox<>(new String[]{"12 PM", "3 PM", "6 PM"});
        timeBox.setPreferredSize(new Dimension(200, 30));
        
        JPanel servicePanel = new JPanel(new GridLayout(4, 1, 5, 5)); 
        servicePanel.setBackground(bgColor);
        servicePanel.add(hairCut);
        servicePanel.add(facial);
        servicePanel.add(massage);
        servicePanel.add(nails);
        
        JPanel timePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        timePanel.setBackground(bgColor);
        timePanel.add(new JLabel("Choose a time:"));
        timePanel.add(timeBox);

        
        JButton confirmButton = new JButton("Confirm Booking");
        confirmButton.setBackground(Color.PINK);
        confirmButton.setFont(new Font("Arial", Font.BOLD, 14));
        confirmButton.setForeground(Color.WHITE);
        confirmButton.setFocusPainted(false);
        confirmButton.setPreferredSize(new Dimension(180, 35));
        
        confirmButton.addActionListener(e -> {
            double total = 0;
            if (hairCut.isSelected()) total += 150;
            if (facial.isSelected()) total += 250;
            if (massage.isSelected()) total += 340;
            if (nails.isSelected()) total += 120;

            String time = (String) timeBox.getSelectedItem();

            saveBooking(total, time);
        });

        
        JButton backButton = new JButton("Back to Menu");
        backButton.setBackground(Color.PINK);
        backButton.setFont(new Font("Arial", Font.BOLD, 14));
        backButton.setForeground(Color.WHITE);
        backButton.setFocusPainted(false);
        backButton.setPreferredSize(new Dimension(180, 35));
        
        backButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
        new MenuWindow(); 
        dispose(); 
    }
});

        
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER)); 
        buttonPanel.setBackground(bgColor);
        buttonPanel.add(confirmButton);
        buttonPanel.add(Box.createVerticalStrut(20)); 
        buttonPanel.add(backButton);

        
        mainPanel.add(servicePanel);
        mainPanel.add(timePanel);
        mainPanel.add(buttonPanel);
        
        
        add(mainPanel, BorderLayout.CENTER);

        setVisible(true);
    }

    
    private void saveBooking(double total, String time) {
        try (FileWriter writer = new FileWriter("bookings.txt", true)) {
            writer.write("Total: SR" + total + ", Time: " + time + "\n");
            JOptionPane.showMessageDialog(this, "Booking saved! Total: SR" + total);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


}
