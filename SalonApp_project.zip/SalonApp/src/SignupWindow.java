import javax.swing.*;
import java.awt.*;
import java.io.FileWriter;
import java.io.IOException;
import static javax.swing.WindowConstants.DISPOSE_ON_CLOSE;

public class SignupWindow extends JFrame {
    public SignupWindow() {
        setTitle("salon - Sign Up");
        setSize(400, 300);
        setLocationRelativeTo(null); 
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

       
        Color bgColor = new Color(255, 228, 225);

        JPanel mainPanel = new JPanel();
        mainPanel.setBackground(bgColor);
        mainPanel.setLayout(new GridLayout(2, 1, 10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JLabel titleLabel = new JLabel("Sign Up a New Account ", JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        add(titleLabel, BorderLayout.NORTH);

        
        JTextField emailField = new JTextField();
        emailField.setBorder(BorderFactory.createTitledBorder("Email"));

        JPasswordField passwordField = new JPasswordField();
        passwordField.setBorder(BorderFactory.createTitledBorder("Password"));

        mainPanel.add(emailField);
        mainPanel.add(passwordField);

        add(mainPanel, BorderLayout.CENTER);

        
        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.setBackground(bgColor);
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JButton registerButton = new JButton("Sign Up");
        customizeButton(registerButton, 30);
        buttonPanel.add(registerButton);

        add(buttonPanel, BorderLayout.SOUTH);

        registerButton.addActionListener(e -> {
            String email = emailField.getText();
            String password = new String(passwordField.getPassword());

            if (email.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill in all fields.");
            } else {
                saveUser(email, password);
                JOptionPane.showMessageDialog(this, "Registration successful!");
                new LoginWindow();
                dispose();
            }
        });

        setVisible(true);
    }

    private void saveUser(String email, String password) {
        try (FileWriter writer = new FileWriter("users.txt", true)) {
            writer.write(email + "," + password + "\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void customizeButton(JButton button, int fontSize) {
        button.setForeground(Color.WHITE);
        button.setBackground(Color.PINK); 
        button.setFont(new Font("Arial", Font.PLAIN, fontSize)); 
    }
    
}
